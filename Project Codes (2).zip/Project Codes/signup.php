<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
      body {
        font-family: Arial, sans-serif;
        background-image: url("wp3745935-bike-and-car-wallpapers.jpg");
        background-size: cover;
        padding: 20px;
        color: #fff;
      }
      form {
        width: 20%;
        margin: auto;
        background-color: rgba(255, 255, 255, 0.1);
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
      }

      input[type="text"], input[type="email"], input[type="password"] {
	 background-color: rgba(255, 255, 255, 0.1);
        width: 60%;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
        color: #000;
      }
      input[type="submit"] {
        padding: 10px 20px;
        border: none;
        background-color: #007BFF;
        color: #fff;
        border-radius: 5px;
        cursor: pointer;
      }
      input[type="submit"]:hover {
        background-color: #0056b3;
      }
</style>

    <?php
if (isset($_POST['signup'])) {
    session_start();
    if (isset($_POST['name']) && isset($_POST['email'])) {
        require 'sql.php';
        $conn = mysqli_connect($host, $user, $ps, $project);        
        if (!$conn) {
            echo "<script>alert(\"Database Error! Retry after some time!\")</script>";
        }
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['pass']);
        $cpassword = mysqli_real_escape_string($conn, $_POST['cpass']);
        $password = crypt($password,'krishnateja');
        $cpassword = crypt($cpassword,'krishnateja');
        if ($password == $cpassword) {
            $sql = "insert into Users (username,email,password) values('$name','$email','$password')";
            if (mysqli_query($conn, $sql)) {
                echo "<script>
                alert('Successfully Signed Up!');
                window.location.replace(\"index.php\");</script>";
                session_destroy();
                }
                else{
                echo "<script>
                alert('Unknown Error, Try again Later!');
                window.location.replace(\"signup.php\");</script>";
                session_destroy();
                }
            } else {
                echo "<script>
                alert('User details already exists in database');
                window.location.replace(\"signup.php\");</script>";
                session_destroy();
            }
        } else {
            echo "<script>
            alert('Password not matched!');
            window.location.replace(\"signup.php\");</script>";
            session_destroy();
        }
    }
?>
    <title>Sign Up</title>
  </head>
  <body>
      <center>
      <h1>User Sign Up</h1>
      <br><br><br>
      <br><br><br>
      <div>
        <form method="POST">
              <label for="name">Name</label><br>
              <input type="text" name="name" required><br><br>
              <label for="email" >e-mail</label><br>
              <input type="email" name="email" required>
              <br><br>
              <label for="pass">Password</label><br>
              <input type="password" name="pass" required><br><br>
              <label for="cpass">Confirm Password</label><br>
              <input type="password" name="cpass" required><br><br><br>
              <input type="submit" name ="signup" value="Sign Up">
          </div>
        </form>
        </center>
  </body>
</html>
