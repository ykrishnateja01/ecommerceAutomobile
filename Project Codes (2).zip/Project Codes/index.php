<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
  <head>
 <style>
      body {
        font-family: Arial, sans-serif;
        background-image: url("wp8887609-bike-for-pc-wallpapers.jpg");
        background-size: cover;
        padding: 20px;
        color: #FFFFE0; 
      }
      form {
        width: 20%;
        margin: auto;
        background-color: rgba(255, 255, 255, 0.1);
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
      }

      input[type="text"], input[type="email"], input[type="password"] {
	 background-color: rgba(255, 255, 255, 0.1);
        width: 60%;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
        color: #000;
      }
      input[type="submit"] {
        padding: 10px 20px;
        border: none;
        background-color: #007BFF;
        color: #fff;
        border-radius: 5px;
        cursor: pointer;
      }
      input[type="submit"]:hover {
        background-color: #0056b3;
      }
</style>

    <?php
        if (isset($_POST['login'])) {
            if (isset($_POST['email']) && isset($_POST['pass'])) {
                require_once 'sql.php';
                $conn = mysqli_connect($host, $user, $ps, $project);
                if (!$conn) {
                    echo "<script>alert('Database Error! Retry after some time!');</script>";
                } else {
                    $email = mysqli_real_escape_string($conn, $_POST['email']);
                    $password = $_POST['pass']; // Get the plain password
                    $sql = "SELECT email, password FROM Users WHERE email=?";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, 's', $email);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    if ($row = mysqli_fetch_assoc($result)) {
                        if (password_verify($password, $row['password'])) {
                            $_SESSION["email"] = $row['email'];
                            echo "<script>window.location.replace('project.html');</script>";
                        } else {
                            echo "<script>alert('Incorrect Password');</script>";
                        }
                    } else {
                        echo "<script>alert('E-mail Not Found In Database');</script>";
                    }
                }
            } else {
                echo "<script>alert('Email and Password Error!');</script>";
            }
        }
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
  </head>
  <body>
      <center>
      <h1>User Login</h1>
      <br><br><br>
      <br><br><br>
      <div>
        <form method="POST">
              <label for="email" >e-mail</label><br>
              <input type="email" name="email" required>
              <br><br>
              <label for="pass">Password</label><br>
              <input type="password" name="pass" required><br><br><br>
              <input type = "submit" name="login" value="Login">
              <br><br>
              <input type = "submit" value="Sign UP" onclick="location.href='signup.php'">
          </div>
        </form>
        </center>
  </body>
</html>